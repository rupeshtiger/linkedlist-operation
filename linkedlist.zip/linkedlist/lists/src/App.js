// src/components/App.js
import React, { useState } from 'react';
import SinglyLinkedList from './LinkedListVisualizer/SinglyLinkedList';
import DoublyLinkedList from './LinkedListVisualizer/DoublyLinkedList';
import CircularLinkedList from './LinkedListVisualizer/CircularLinkedList';
import LinkedListControls from './LinkedListVisualizer/LinkedListControls';
import './App.css';

const App = () => {
    const [activeVisualizer, setActiveVisualizer] = useState('singlyLinkedList');

    const renderVisualizer = () => {
        switch (activeVisualizer) {
            case 'singlyLinkedList':
                return <SinglyLinkedList />;
            case 'doublyLinkedList':
                return <DoublyLinkedList />;
            case 'circularLinkedList':
                return <CircularLinkedList />;
            default:
                return <SinglyLinkedList />;
        }
    };

    return (
        <div className="App">
            <h1>Linked List Visualizer</h1>
            {renderVisualizer()}
            <LinkedListControls setVisualizer={setActiveVisualizer} />
        </div>
    );
};

export default App;
