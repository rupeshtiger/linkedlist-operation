// src/components/LinkedListVisualizer/LinkedListControls.js
import React from 'react';
import './LinkedListVisualizer.css';

const LinkedListControls = ({ setVisualizer }) => {
    const handleClick = (type) => () => setVisualizer(type);

    return (
        <div className="controls">
            <button onClick={handleClick('singlyLinkedList')}>Singly Linked List</button>
            <button onClick={handleClick('doublyLinkedList')}>Doubly Linked List</button>
            <button onClick={handleClick('circularLinkedList')}>Circular Linked List</button>
        </div>
    );
};

export default LinkedListControls;
