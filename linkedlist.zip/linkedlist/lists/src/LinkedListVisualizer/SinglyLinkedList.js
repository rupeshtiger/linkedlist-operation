// src/components/LinkedListVisualizer/SinglyLinkedList.js
import React, { useState } from 'react';
import './LinkedListVisualizer.css';

const SinglyLinkedList = () => {
    const [list, setList] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [searchValue, setSearchValue] = useState('');
    const [searchResult, setSearchResult] = useState(null);

    const addNode = () => {
        if (inputValue.trim()) {
            setList([...list, { value: inputValue }]);
            setInputValue('');
        }
    };

    const removeNode = () => {
        setList(list.slice(0, -1));
    };

    const searchNode = () => {
        const index = list.findIndex(node => node.value === searchValue);
        setSearchResult(index >= 0 ? index : 'Not Found');
    };

    return (
        <div className="visualizer">
            <div className="list">
                {list.map((node, index) => (
                    <div key={index} className={`list-node ${searchResult === index ? 'highlight' : ''}`}>
                        {node.value}
                        {index < list.length - 1 && <span className="arrow">→</span>}
                    </div>
                ))}
            </div>
            <div className="controls">
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Enter node value"
                />
                <button onClick={addNode}>Add Node</button>
                <button onClick={removeNode}>Remove Node</button>
            </div>
            <div className="search-controls">
                <input
                    type="text"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                    placeholder="Search value"
                />
                <button onClick={searchNode}>Search Node</button>
                {searchResult !== null && (
                    <div className="search-result">
                        {searchResult === 'Not Found' ? 'Node not found' : `Node found at index ${searchResult}`}
                    </div>
                )}
            </div>
        </div>
    );
};

export default SinglyLinkedList;
